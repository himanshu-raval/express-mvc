module.exports = Config = {
	minPlayers: 2,
	maxPlayers: 4,
	playerHandCards: 5,
}