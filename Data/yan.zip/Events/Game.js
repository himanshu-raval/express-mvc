var Game = require('../Boot/Game');

Game.prototype.addEvents = function(){
	
}


module.exports = Game = Game;