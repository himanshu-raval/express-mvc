import { Component, OnInit } from '@angular/core';

@Component({
    selector: 'app-bs-element',
    templateUrl: './bs-element.component.html',
    styleUrls: ['./bs-element.component.scss']
})
export class BsElementComponent implements OnInit {
    constructor() { }
    ngOnInit() { }
}
