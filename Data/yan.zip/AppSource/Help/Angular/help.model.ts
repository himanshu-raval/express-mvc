export class Help {
    text: string;
    video: string;
}