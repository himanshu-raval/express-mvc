export const shopConfig = {
     apiUrl: 'http://192.168.1.86:8000'
    // apiUrl: 'http://localhost:8000'
    // apiUrl: 'http://35.165.51.160:8000/'
};

