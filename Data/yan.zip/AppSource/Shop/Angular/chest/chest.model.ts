export class Chest {
    id: string;
    appId: string;
    username: string;
    email: string;
    phone: string;
    status: string;
}