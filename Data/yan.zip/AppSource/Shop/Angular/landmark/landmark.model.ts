export class Landmark {
    id: string;
    appId: string;
    username: string;
    email: string;
    phone: string;
    status: string;
}