export class Card {
    id: string;
    appId: string;
    username: string;
    email: string;
    phone: string;
    status: string;
}