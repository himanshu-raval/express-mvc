module.exports = {
    jokers:2,
    playerHandCards:5,
    botWaitngTime:10000 // Milisecond
}